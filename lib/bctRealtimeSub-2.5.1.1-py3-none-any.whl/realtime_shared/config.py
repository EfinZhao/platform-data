import os
PUBLISHER_AUTH_ADDRESS = ""
SUBSCRIBER_AUTH_ADDRESS = ""



METADATA_KEY_TYPE= "type"
METADATA_KEY_TOKEN= "token"
METADATA_KEY_UDID= "bct-udid"
METADATA_KEY_SERVICE="service"
METADATA_KEY_CHALLENGE = "challenge"
# METADATA_KEY_CHALLENGE_RAND = "challenge_rand"
# METADATA_KEY_CHALLENGE_TIME = "challenge_time"


CONNECTION_TYPE_PUBLISHER = "1"
CONNECTION_TYPE_SUBSCRIBER_API = "2"
CONNECTION_TYPE_SUBSCRIBER_SERVICE = "3"
CONNECTION_TYPE_PUBLISHER_SSC = "4"
CONNECTION_TYPE_SUBSCRIBER_SSC = "5"




ADDRESS_BASE_COREAPI = os.getenv("service_url_core","https://core.api.bluecity.ai/")
# ADDRESS_BASE_COREAPI = "https://core.api.bluecity.ai/"

ADDRESS_AUTH_PUBLISHER= ADDRESS_BASE_COREAPI+ "s/a/"
ADDRESS_AUTH_SERVICE= ADDRESS_BASE_COREAPI+ "s/service/validate/"

KEY_CORE_SING=os.getenv("realtimeapi_jwt_public",open("realtime_server/credentials/subscriber_api.key.pub","rb").read())
KEY_SUB_API=os.getenv("realtimeapi_jwt_public",open("realtime_server/credentials/subscriber_api.key.pub","rb").read())
UNITS_CPU = int(os.getenv("realtime_cpu_units","1024"))


METADATA_URL = os.environ.get("ECS_CONTAINER_METADATA_URI_V4","http://localhost") + "/task/stats"


LOAD_THRESHOLD=85
LOAD_IDEAL = 70