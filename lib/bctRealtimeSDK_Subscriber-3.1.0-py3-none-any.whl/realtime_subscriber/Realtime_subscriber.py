"""
This is the base class of realtime subsciber. subscriber_service and API is drived from this base class.
BCTWSConnection implements realtime_subscriber stub in secure and insecure mode. 
By default, the secure mode( over the ssl ) is enabled. 
"""

import requests
from realtime_shared import realtime_pb2_grpc as  realtime_subscriber_pb2_grpc
from realtime_shared import realtime_pb2 as realtime_subscriber_pb2
import grpc
import time
import multiprocessing
import enum
from realtime_subscriber import header_manipulator_client_interceptor
import logging
import atexit
from logging.handlers import TimedRotatingFileHandler
from logging import Formatter,StreamHandler
import signal
from typing import Union
import ctypes
import datetime

class SubAuth(grpc.AuthMetadataPlugin):
    def __init__(self, udid, key):
        self._udid=udid
        self._key = key

        super().__init__()

    def __call__(self, context, callback):
        # callback((('bct-udid', self._udid),('rpc-auth-header-subscriber-user', self._key)), None)
        callback((('bct-udid', self._udid),('token', self._key),('type', '2')), None)




class BCTWSConnection:
    """
    This is the connection class. It implements connection to the server using realtime_subscriber stub. 
    This class 
    """

    def cleanUp(self):
        self.logger.info("cleaning background processes")
        self.p.terminate()
    class subscriptionOption(enum.Enum):
        FRAME=0
        LOOP_CHANGE=1
        PHASE_CHANGE=2
        DETECTION_FRAME=3
        PHASE_TIME_TO_CHANGE=4

    def __init__(self, UDID:str, token:str, serverAddress : Union[str, None] =None  ,beaconAddress="https://realtime.us.beacon.1.api.bluecity.ai/",subscriptions=(subscriptionOption.FRAME,), cacheSize=400,singleton=False,TLS=True,semantic_abs=True):
        """
        Using this class you can get connected to the Blucity realtime server 

        Args: 
            UDID (str): UDID of the sensor you want to subscribe to
            token (str): Authentication token
            serverAddress (str): Realtime server address. If a values is passed, module won't ask beacon for the address and gets connected directly 
            to the requested address
            beaconAddress (str): Domain address of the beacon. Beacon is a lookaside load balancer that routes the connection to the proper server
            subscriptions (BCTWSConnection.subscriptionOption): You can set the data you want to receive from the server. 
            cacheSize (int): Idicates the size of the backlog used for caching the received data from the server
            singleton (bool): Indicates  the format you want to receive data. Data can be either send packaged as a hyper parameter (singleton True) or can be fetched 
            separately for each stream (singleton False)
            TLS (bool): Is the connection to the server going to be over the TLS or not.
            semantic_abs (bool): If this flag is set to True, it removes the absolute flags if there has not been any changes to the last recorded abs
        
        Returns:
            BCTWSConnection object

        """
        self.UDID = UDID.lower()
        self.token = token
        
        self.askBeacon = True if serverAddress is None else False
        self.serverAdd = serverAddress
        self.beaconAddress= beaconAddress
        self.cacheSize = cacheSize
        self.isConnectionSecured = TLS

        self.pingPeriod=5


        self.isInitialized_lock = multiprocessing.Lock()
        self.isInitialized=multiprocessing.Value(ctypes.c_bool,False) # False
        self.force_cancel_lock = multiprocessing.Lock()
        self.force_cancel=multiprocessing.Value(ctypes.c_bool,False) # flag 

        self.singleton = singleton

        subscriptions = set(subscriptions)

        if  not self.singleton : 
            """
            If it is not set as singelton we are going to have 4 seperate threads and qeues for each part. Frame, dection Frame, Phase and occupancy
            """
            self.isSubscribed_frame=False
            self.isSubscribed_occupancy=False
            self.isSubscribed_phase=False
            self.isSubscribed_detectionFrame=False
            self.isSubscribed_phaseTimeToChange=False

            if BCTWSConnection.subscriptionOption.FRAME in subscriptions:
                self.frames = multiprocessing.Queue()
                self.isSubscribed_frame=True
                self.initialized_frame = False

            if BCTWSConnection.subscriptionOption.DETECTION_FRAME in subscriptions:
                self.detectionFrames = multiprocessing.Queue()
                self.isSubscribed_detectionFrame=True
                self.initialized_detectionFrame = False

            if BCTWSConnection.subscriptionOption.LOOP_CHANGE in subscriptions:
                self.occupancies = multiprocessing.Queue()
                self.isSubscribed_occupancy=True
                self.initialized_occupancy = False


            if BCTWSConnection.subscriptionOption.PHASE_CHANGE in subscriptions:
                self.phases = multiprocessing.Queue()
                self.isSubscribed_phase=True
                self.initialized_phase = False

            if BCTWSConnection.subscriptionOption.PHASE_TIME_TO_CHANGE in subscriptions:
                self.phaseTimeToChanges = multiprocessing.Queue()
                self.isSubscribed_phaseTimeToChange=True
                self.initialized_phaseTimeToChange = False

            
        else:
            """
            in case of singelton, it's gonna be only one qeue contains everything
            """
            # self.queue = multiprocessing.Queue(maxsize=self.cacheSize)
            m = multiprocessing.Manager()
            self.queue = m.Queue()

        self.subscriptions = self.__convert_clientSubOp_serverSubOp(subscriptions)

        self.last_abs_phase=  None # will be set() 
        self.last_abs_occupancy= None # will be set()  
        self.time_last_msg_recv=None
        self.semantic_abs=semantic_abs

        self.createLogger()
    

        # multiprocessing.Process(target=self.connect_secure).start()   
        atexit.register(self.cleanUp)
        self.p = multiprocessing.Process(target=self.run,daemon=True)
        self.p.start()
    
    def createLogger(self):
        if hasattr(self,"logger") and self.logger is not None:
            return
            
        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(logging.INFO)

        # Create handler
        # handler = TimedRotatingFileHandler(filename='realtime_subscriber.log', when='midnight', interval=1, backupCount=3, encoding='utf-8', delay=False)
        handler = StreamHandler()
        
        formatter = Formatter(fmt="Realtime-Subscriber (%(levelname)s): %(asctime)s.%(msecs)03d - %(name)s:%(lineno)d - %(message)s")
        handler.setFormatter(formatter)
        self.logger.addHandler(handler)
        self.logger.info("logger is created")

    def __pushToQueue(self,obj,queue):
        if queue.qsize() >= self.cacheSize:
            try:
                queue.get_nowait()
            except:
                self.logger.warning("was not able to reduce the size of fulled queue")
            
        try:
            queue.put_nowait(obj)
        except:
            self.logger.warning("was not able to put item in the queue")

    def restart(self,requestInitial=True):
        with self.force_cancel_lock:
            self.force_cancel.value=True
        
        with self.isInitialized_lock:
            self.isInitialized.value=False
    
    
    def __convert_clientSubOp_serverSubOp(self,subscriptions):
        subscriptionOption = []
        for sub in subscriptions:
            serverSubOp=None
            if BCTWSConnection.subscriptionOption.FRAME == sub:
                serverSubOp = realtime_subscriber_pb2.SubscriptionRequest.STREAM_OPTION.FRAME
            elif BCTWSConnection.subscriptionOption.DETECTION_FRAME == sub:
                serverSubOp = realtime_subscriber_pb2.SubscriptionRequest.STREAM_OPTION.DETECTION_FRAME
            elif BCTWSConnection.subscriptionOption.LOOP_CHANGE == sub:
                serverSubOp = realtime_subscriber_pb2.SubscriptionRequest.STREAM_OPTION.OCCUPANCY_CHANGE
            elif BCTWSConnection.subscriptionOption.PHASE_CHANGE == sub:
                serverSubOp = realtime_subscriber_pb2.SubscriptionRequest.STREAM_OPTION.PHASE_CHANGE
            elif BCTWSConnection.subscriptionOption.PHASE_TIME_TO_CHANGE == sub:
                serverSubOp = realtime_subscriber_pb2.SubscriptionRequest.STREAM_OPTION.PHASE_TIME_TO_CHANGE

            if serverSubOp is not None:
                subscriptionOption.append(serverSubOp)

        return subscriptionOption if len(subscriptionOption)>0 else None

    def __semantic_abs_phase_check(self,item):
        # check for semantic filtering 
        if self.time_last_msg_recv is not None \
                and self.last_abs_phase is not None \
                and abs((datetime.datetime.strptime(item.timestamp,"%Y-%m-%dT%H:%M:%S.%f") - datetime.datetime.strptime(self.time_last_msg_recv,"%Y-%m-%dT%H:%M:%S.%f")).total_seconds())<.5:
            # check for the abs sanity 
            
            self.last_abs_phase:set
            remove_abs=True
            for phase_ in item.phaseChange.phases:
                if phase_.phaseNumber not in self.last_abs_phase:
                    # ignore everything and send abs
                    remove_abs=False
                    break   
            if remove_abs:
                item.phaseChange.absolute=False
        
        # update last_abs_phase
        if self.last_abs_phase is None:
            self.last_abs_phase=set()
        self.last_abs_phase.clear()
        for phase_ in item.phaseChange.phases:
            self.last_abs_phase.add(phase_.phaseNumber)

    def __semantic_abs_occupancy_check(self,item):
        # check for semantic filtering 
        if self.time_last_msg_recv is not None \
                and self.last_abs_occupancy is not None \
                and abs((datetime.datetime.strptime(item.timestamp,"%Y-%m-%dT%H:%M:%S.%f") - datetime.datetime.strptime(self.time_last_msg_recv,"%Y-%m-%dT%H:%M:%S.%f")).total_seconds())<.5:
            # check for the abs sanity 
            
            self.last_abs_occupancy:set
            remove_abs=True
            for occupancy in item.occupancyChange.occupancies:
                if occupancy.phaseLabel not in self.last_abs_occupancy:
                    # ignore everything and send abs
                    remove_abs=False
                    break   
            if remove_abs:
                item.occupancyChange.absolute=False
        
        # update last_abs_occupancy
        if self.last_abs_occupancy is None:
            self.last_abs_occupancy=set()
        self.last_abs_occupancy.clear()
        for occupancy in item.occupancyChange.occupancies:
            self.last_abs_occupancy.add(occupancy.phaseLabel)
    
    def __subscribe(self,stub):

        response=stub.subscribe(realtime_subscriber_pb2.SubscriptionRequest(initial = not self.isInitialized.value,subscriptionOption=self.subscriptions))
        item:realtime_subscriber_pb2.HyperParameter
        def cancelSubscription(signum, stack_frame):
            print("=========================================================================================")
            response.cancel()
            quit(0)

        signal.signal(signal.SIGINT,cancelSubscription)
        for item in response:
            if self.force_cancel.value:
                response.cancel()
                return
            
            if not self.isInitialized:
                with self.isInitialized_lock:
                    self.isInitialized.value=True


            if self.semantic_abs:
                # filter abs
                message_init= item.initial
                phase_abs_flag = item.phaseChange.absolute
                occupancy_abs_flag =item.occupancyChange.absolute
                if  phase_abs_flag:
                    self.__semantic_abs_phase_check(item)

                if  occupancy_abs_flag:
                    self.__semantic_abs_occupancy_check(item)
                self.time_last_msg_recv = item.timestamp


            if self.singleton:
                if item.timestamp.strip()!="":
                    self.__pushToQueue(item,self.queue)
            else:
                if item.timestamp.strip()!="":
                    #TODO: check the subscription of users
                    if self.isSubscribed_frame:
                        item.frame.timestamp = item.timestamp
                        self.__pushToQueue(item.frame,self.frames)

                    if self.isSubscribed_phase :
                        item.phaseChange.timestamp = item.timestamp
                        self.__pushToQueue(item.phaseChange,self.phases)

                    if self.isSubscribed_occupancy:
                        #occupancyChange doesn't have timestamp attribute 
                        self.__pushToQueue(item.occupancyChange,self.occupancies)

                    if self.isSubscribed_phaseTimeToChange:
                        item.phaseTimeToChange.timestamp = item.timestamp
                        self.__pushToQueue(item.phaseTimeToChange,self.phaseTimeToChanges)

                    if self.isSubscribed_detectionFrame:
                        item.detectionFrame.timestamp = item.timestamp
                        self.__pushToQueue(item.detectionFrame,self.detectionFrames)


    def ping(self,stub):
        while True:
            time.sleep(self.pingPeriod)
            stub.ping(realtime_subscriber_pb2.Empty())

    def run (self):
        # create a seperate logger for this process
        self.logger = None
        self.createLogger()
        
        if self.isConnectionSecured:
            self.connect_secure()
        else:
            self.connect_insecure()
        
    def getCredentials_beacon(self):

        while self.serverAdd is None:
            self.crt = ""
            try:
                res = requests.post(self.beaconAddress+"route",json={"UDID":self.UDID,"type":"2","token":self.token})
                if res.status_code ==200:
                    res = res.json()
                    self.serverAdd= res["address"]
                    self.crt =  res["key"].encode()
                    # _credentials.ROOT_CERTIFICATE = res["key"]
                    break
                else:
                    raise Exception()
            except Exception as ex:
                self.logger.error("Beacon is unreachable. Error {}".format(str(ex)))
                time.sleep(5)

    def connect_secure(self):

        while True:
            try:
                if self.askBeacon:
                    self.getCredentials_beacon()

                self.logger.info("connecting to the server {}".format(self.serverAdd))
                call_credentials = grpc.metadata_call_credentials(SubAuth(self.UDID,self.token),"subAuth")
                channel_credential = grpc.ssl_channel_credentials(self.crt)
                composite_credentials= grpc.composite_channel_credentials(channel_credential,call_credentials)
                with grpc.secure_channel('{}'.format(self.serverAdd), composite_credentials) as channel:
                    stub = realtime_subscriber_pb2_grpc.SubscriberStub(channel)
                    self.__subscribe(stub)
            except grpc.RpcError as e:
                e.details()
                status_code = e.code()
                self.logger.error (status_code.name,status_code.value)
            except Exception as ex:
                self.logger.critical(str(ex))
            finally:
                if self.askBeacon:
                    self.serverAdd=None
                if self.force_cancel.value:
                    with self.force_cancel_lock:
                        self.force_cancel.value=False
                    # we don't need to wait since the command is comming from the client
                else:
                    time.sleep(5) 

    def connect_insecure(self):


        while True:
            try:
                if self.askBeacon:
                    self.getCredentials_beacon()
                    
                self.logger.info("connecting to the server")
                with grpc.insecure_channel(self.serverAdd) as channel:
                    header_adder_interceptor = header_manipulator_client_interceptor.header_adder_interceptor(['bct-udid','token','type'], [self.UDID,self.token,'2'])
                    intercept_channel = grpc.intercept_channel(channel,header_adder_interceptor)

                    stub = realtime_subscriber_pb2_grpc.SubscriberStub(intercept_channel)

                    # threading.Thread(target=self.ping,args=[stub]).start()
                    self.__subscribe(stub)
            except Exception as ex: 
                self.logger.error("Connection to the server is lost. Retry in 5 seconds")
            finally:
                if self.askBeacon:
                    self.serverAdd=None
                if self.force_cancel.value:
                    with self.force_cancel_lock:
                        self.force_cancel.value=False
                    # we don't need to wait since the command is comming from the client
                else:
                    time.sleep(5)     



    # ─── GET NOT SINGLETON ITEMS ────────────────────────────────────────────────────
    def get(self):
        frame_ = self.frames.get()
        strFormat=frame_.timestamp +','
        for obj in frame_.objects:
            strFormat+= obj.id +','
            strFormat+= str(obj.centerX) +','
            strFormat+= str(obj.centerY )+','
            strFormat+= str(obj.width )+','
            strFormat+= str(obj.length) +','
            strFormat+= str(obj.classType) +','
            strFormat+= '1,'
            strFormat+= str(obj.rotation) +','
            strFormat+= '1,'
            strFormat+= '1,'

        strFormat+= '<EOF>'

            
        return strFormat

    def get_frame(self):
        time.sleep(0.001)

        try:
            return self.frames.get()
        except:
            self.logger.critical("can not fetch frame data")

    def get_detectionFrame(self):
        time.sleep(0.001)

        try:
            return self.detectionFrames.get()
        except:
            self.logger.critical("can not fetch frame data")

    def get_occupancy(self):
        time.sleep(0.001)
        try:
            return self.occupancies.get()
        except:
            self.logger.critical("can not fetch occupancy data")

    def get_phase(self):
        time.sleep(0.001)
        try:
            return self.phases.get()
        except:
            self.logger.critical("can not fetch phase data")

    def get_phaseTimeToChange(self):
        time.sleep(0.001)
        try:
            return self.phaseTimeToChanges.get()
        except:
            self.logger.critical("can not fetch phaseTimeToChange data")

    # ────────────────────────────────────────────────────────────────────────────────


    # ─── GET SINGLETON ITEM ─────────────────────────────────────────────────────────

    def get_hyperparameter(self):
        time.sleep(0.001)
        return self.queue.get()
    # ────────────────────────────────────────────────────────────────────────────────

   

